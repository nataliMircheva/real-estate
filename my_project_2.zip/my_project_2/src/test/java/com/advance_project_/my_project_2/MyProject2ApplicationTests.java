package com.advance_project_.my_project_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyProject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
