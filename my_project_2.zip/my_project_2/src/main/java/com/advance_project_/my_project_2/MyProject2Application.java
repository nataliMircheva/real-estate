package com.advance_project_.my_project_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(MyProject2Application.class, args);
	}

}
